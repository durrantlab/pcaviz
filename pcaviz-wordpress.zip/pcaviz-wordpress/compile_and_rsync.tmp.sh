cd ../pcaviz-interpreter-javascript/
./compile.sh
cd -
cp ../pcaviz-interpreter-javascript/PCAViz.min.js ./assets/js/PCAViz.min.js
rsync -rv ../pcaviz-wordpress durrantj@durrantlab.pitt.edu:/var/www/html/wp-content/plugins/
